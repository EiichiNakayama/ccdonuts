<?php require 'header.php'; ?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="common/reset.css">
    <link rel="stylesheet" href="styles/style.css">
    <title>Document</title>
</head>
<body class=topPage>
<header> 
        <h1>
         <img src="images/heroImage.png" alt="heroimage">    
        </h1>

</header>
    <main>
        <section>
            <ul class="proDucts">
                <li class="item01"><img src="images/newProductintroduce.png" alt=""></li>
                <li class="item02"><img src="images/donutsLife.png" alt=""></li>
                <li class="item03"><img src="images/productsBanner.png" alt=""></li>
            </ul> 
        </section>
   
    </main>
     
</body>
</html>
<?php require 'footer.php'; ?>
